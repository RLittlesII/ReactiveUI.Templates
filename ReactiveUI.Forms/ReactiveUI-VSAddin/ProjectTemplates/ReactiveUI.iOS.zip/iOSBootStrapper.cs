﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using UIKit;

namespace $safeprojectname$.Startup
{
    public class iOSBootStrapper : AppBootstrapper
    {
        public override void RegisterPlatformServices()
        {
            // Register your iOS specific implemntations here.
        }
    }
}